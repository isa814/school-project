import Link from "next/link";
import { Logo } from "@/components/shared/Logo";

export function Footer() {
  return (
    <footer className="lattice-navy text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo tone="light" href={null} />
          <p className="mt-4 max-w-md text-sm leading-relaxed text-sky/90">
            Nurturing knowledgeable, disciplined and God-conscious young people from Nursery through Senior Secondary. Knowledge is light.
          </p>
        </div>
        <div>
          <h2 className="font-display text-base font-semibold text-white">Explore</h2>
          <ul className="mt-3 space-y-2 text-sm text-sky/90">
            <li><Link className="hover:text-white" href="/about">About us</Link></li>
            <li><Link className="hover:text-white" href="/academics">Academics</Link></li>
            <li><Link className="hover:text-white" href="/admissions">Admissions</Link></li>
            <li><Link className="hover:text-white" href="/news">News & events</Link></li>
            <li><Link className="hover:text-white" href="/policies">Policies</Link></li>
          </ul>
        </div>
        <div>
          <h2 className="font-display text-base font-semibold text-white">Contact</h2>
          <ul className="mt-3 space-y-2 text-sm text-sky/90">
            {/* TODO: replace with the school's real address, phone and email */}
            <li>Lagos, Nigeria</li>
            <li>+234 800 000 0000</li>
            <li>info@ansarruhul.demo</li>
            <li><Link className="hover:text-white" href="/login">Portal login</Link></li>
            <li><Link className="hover:text-white" href="/privacy">Privacy policy</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-sky/80">
        © {new Date().getFullYear()} Ansar Ruhul Islam Nursery, Primary &amp; Secondary School. All rights reserved.
      </div>
    </footer>
  );
}
