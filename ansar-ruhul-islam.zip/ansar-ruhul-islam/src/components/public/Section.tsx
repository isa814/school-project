import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Section({ id, className, children }: { id?: string; className?: string; children: ReactNode }) {
  return <section id={id} className={cn("mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20", className)}>{children}</section>;
}

export function SectionTitle({ eyebrow, title, description, center = false }: { eyebrow?: string; title: string; description?: string; center?: boolean }) {
  return (
    <div className={cn("mb-10 max-w-2xl", center && "mx-auto text-center")}>
      {eyebrow && <p className="text-xs font-semibold uppercase tracking-[0.18em] text-navy/70">{eyebrow}</p>}
      <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-navy-deep sm:text-4xl">{title}</h2>
      {description && <p className="mt-3 text-base leading-relaxed text-slate-600">{description}</p>}
    </div>
  );
}

/** Subtle Islamic-inspired star pattern used as a divider. */
export function StarDivider() {
  return (
    <svg aria-hidden viewBox="0 0 200 24" className="mx-auto h-6 w-48 text-sky">
      <path d="M100 2 L108 10 L118 12 L108 14 L100 22 L92 14 L82 12 L92 10 Z" fill="currentColor" opacity="0.7" />
      <line x1="0" y1="12" x2="82" y2="12" stroke="currentColor" strokeOpacity="0.5" />
      <line x1="118" y1="12" x2="200" y2="12" stroke="currentColor" strokeOpacity="0.5" />
    </svg>
  );
}
