import { requireRole } from "@/lib/session";
import { myStudent } from "@/lib/services/student-portal";
import { changePasswordAction } from "@/app/actions/student";
import { PageHeader } from "@/components/shared/PageHeader";
import { Flash } from "@/components/shared/Flash";
import { Card, CardContent, CardHeader, CardTitle, Input, Label, SubmitButton, Notice } from "@/components/ui";
import { formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function StudentProfile({ searchParams }: { searchParams: { ok?: string; err?: string } }) {
  const user = await requireRole("STUDENT");
  const student = await myStudent(user.id);
  if (!student) return <Notice tone="error">Your student profile is not linked to this account.</Notice>;
  const primary = student.guardians[0];
  const rows: [string, string][] = [
    ["Full name", `${student.firstName} ${student.lastName}`],
    ["Admission number", student.admissionNo],
    ["Class", `${student.class.name} ${student.section.name}`],
    ["Date of birth", student.dob ? formatDate(student.dob) : "Not recorded"],
    ["Gender", student.gender],
    ["Admitted", formatDate(student.admissionDate)],
    ["Login email", user.email],
    ["Primary guardian", primary ? `${primary.name} (${primary.relationship}) · ${primary.phone}` : "Not recorded"],
  ];
  return (
    <>
      <PageHeader eyebrow="Account" title="My profile" description="Your details are maintained by the school office. You can change your password here." />
      <Flash ok={searchParams.ok} err={searchParams.err} />
      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Student details</CardTitle></CardHeader>
          <CardContent>
            <dl className="grid gap-3 text-sm sm:grid-cols-2">
              {rows.map(([k, v]) => (
                <div key={k} className="rounded-xl bg-sky-soft/60 p-3">
                  <dt className="text-xs font-semibold uppercase tracking-wide text-slate-500">{k}</dt>
                  <dd className="mt-1 font-medium text-navy-deep">{v}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-4 text-xs text-slate-500">To correct any detail, contact the school office. Parents and guardians do not have separate logins; use Guardian View with the Guardian PIN.</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Change password</CardTitle></CardHeader>
          <CardContent>
            <form action={changePasswordAction} className="space-y-4">
              <div>
                <Label htmlFor="current">Current password</Label>
                <Input id="current" name="current" type="password" autoComplete="current-password" required />
              </div>
              <div>
                <Label htmlFor="next">New password</Label>
                <Input id="next" name="next" type="password" autoComplete="new-password" minLength={8} required />
              </div>
              <div>
                <Label htmlFor="confirm">Confirm new password</Label>
                <Input id="confirm" name="confirm" type="password" autoComplete="new-password" minLength={8} required />
              </div>
              <p className="text-xs text-slate-500">At least 8 characters. Use a password you do not use anywhere else.</p>
              <SubmitButton pendingText="Updating…">Update password</SubmitButton>
            </form>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
