import { requireRole } from "@/lib/session";
import { DashboardShell, type NavItem } from "@/components/shared/DashboardShell";

const NAV: NavItem[] = [
  { href: "/student", label: "Home", icon: "LayoutDashboard" },
  { href: "/student/timetable", label: "Timetable", icon: "Clock" },
  { href: "/student/attendance", label: "Attendance", icon: "ClipboardList" },
  { href: "/student/assignments", label: "Assignments", icon: "BookMarked" },
  { href: "/student/results", label: "Results", icon: "GraduationCap" },
  { href: "/student/fees", label: "Fees & receipts", icon: "Wallet" },
  { href: "/student/guardian", label: "Guardian View", icon: "ShieldCheck" },
  { href: "/student/profile", label: "My profile", icon: "UserRound" },
];

export default async function StudentLayout({ children }: { children: React.ReactNode }) {
  const user = await requireRole("STUDENT");
  return <DashboardShell area="Student" userName={user.name} roleLabel="Student" nav={NAV}>{children}</DashboardShell>;
}
