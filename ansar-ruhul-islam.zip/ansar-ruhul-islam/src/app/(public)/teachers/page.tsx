import type { Metadata } from "next";
import { UserRound } from "lucide-react";
import { db } from "@/lib/db";
import { Section, SectionTitle } from "@/components/public/Section";

export const metadata: Metadata = { title: "Our teachers", description: "Meet the teaching staff of Ansar Ruhul Islam School." };

/** Public directory: name, department and a short bio only. No private data is selected. */
export default async function TeachersPage() {
  const staff = await db.staff.findMany({
    where: { deletedAt: null, user: { role: "TEACHER", isActive: true } },
    select: { id: true, firstName: true, lastName: true, qualification: true, bio: true, department: { select: { name: true } } },
    orderBy: { lastName: "asc" },
  });
  return (
    <>
      <div className="lattice-navy text-white">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-sky">Our teachers</p>
          <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight sm:text-5xl">Dedicated educators</h1>
        </div>
      </div>
      <Section>
        <SectionTitle title="Teaching staff" description="Each teacher is committed to academic success and good character." />
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {staff.map((t) => (
            <li key={t.id} className="rounded-2xl border border-navy/10 bg-white p-6 text-center shadow-card">
              <span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-sky-soft text-navy" aria-hidden><UserRound className="h-9 w-9" /></span>
              <h2 className="mt-4 font-display text-lg font-semibold text-navy-deep">{t.firstName} {t.lastName}</h2>
              <p className="text-sm font-medium text-navy">{t.department?.name ?? "Teaching staff"}</p>
              <p className="mt-1 text-xs text-slate-500">{t.qualification ?? ""}</p>
              <p className="mt-3 text-sm text-slate-600">{t.bio ?? "Committed to excellence in teaching and mentorship."}</p>
            </li>
          ))}
        </ul>
        {staff.length === 0 && <p className="text-slate-600">Our teaching profiles will appear here soon.</p>}
      </Section>
    </>
  );
}
