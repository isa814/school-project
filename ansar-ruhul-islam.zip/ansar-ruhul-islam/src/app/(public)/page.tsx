import Link from "next/link";
import Image from "next/image";
import type { Metadata } from "next";
import { GraduationCap, BookOpen, Info, Users, Newspaper, ImageIcon, MessagesSquare, Phone, Star, ArrowRight } from "lucide-react";
import { db } from "@/lib/db";
import { buttonVariants } from "@/components/ui";
import { cn } from "@/lib/utils";
import { Section, SectionTitle, StarDivider } from "@/components/public/Section";

export const metadata: Metadata = {
  title: "Home",
  description: "Ansar Ruhul Islam Nursery, Primary and Secondary School in Lagos. Admissions for JSS1 to SS3 are open.",
};
export const revalidate = 300;

/** Each card opens its own page. The home page only summarises. */
const PAGES = [
  { href: "/about", icon: Info, title: "About us", body: "Our mission, values, leadership and the faith-based character of the school." },
  { href: "/academics", icon: BookOpen, title: "Academics", body: "The curriculum from JSS1 to SS3, subjects by department and how we assess progress." },
  { href: "/teachers", icon: Users, title: "Teachers", body: "Meet the dedicated educators who know every learner and mentor them personally." },
  { href: "/admissions", icon: GraduationCap, title: "Admissions", body: "How to apply, the requirements, important dates and how to track your application." },
  { href: "/news", icon: Newspaper, title: "News & events", body: "Latest school news, the academic calendar and upcoming events." },
  { href: "/gallery", icon: ImageIcon, title: "Gallery", body: "Life at Ansar Ruhul Islam School, in classrooms, on the field and at prayer." },
  { href: "/forum", icon: MessagesSquare, title: "Parent forum", body: "Questions and discussion for parents, moderated by the school." },
  { href: "/contact", icon: Phone, title: "Contact", body: "Reach the school office by phone, email or a message through this form." },
];

export default async function HomePage() {
  const [studentCount, teacherCount, scores] = await Promise.all([
    db.student.count({ where: { deletedAt: null, status: "ACTIVE" } }),
    db.staff.count({ where: { deletedAt: null, user: { role: "TEACHER" } } }),
    db.score.findMany({ where: { status: { in: ["APPROVED", "LOCKED"] } }, select: { grade: true } }),
  ]);
  const passRate = scores.length ? Math.round((scores.filter((s) => s.grade && s.grade !== "F9").length / scores.length) * 100) : null;

  return (
    <>
      {/* Hero */}
      <section className="lattice-navy relative overflow-hidden text-white">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-sky/40 bg-white/5 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-sky">
              <Star className="h-3.5 w-3.5" aria-hidden /> Admissions open for 2026/2027
            </p>
            <h1 className="mt-6 font-display text-4xl font-semibold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">
              Knowledge is light. <span className="text-sky">Raise a child who shines.</span>
            </h1>
            {/* TODO: replace with the principal's approved school tagline */}
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/85">
              Ansar Ruhul Islam Nursery, Primary and Secondary School combines rigorous academics with Islamic values, from the nursery to Senior Secondary.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Link href="/admissions/apply" className={cn(buttonVariants({ variant: "sky", size: "lg" }))}>Apply for Admission</Link>
              <Link href="/about" className={cn(buttonVariants({ variant: "outline", size: "lg" }), "border-white/30 bg-transparent text-white hover:bg-white/10")}>Discover the school</Link>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-xl">
            <div className="absolute -inset-6 rounded-[2rem] bg-sky/10 blur-2xl" aria-hidden />
            <div className="relative overflow-hidden rounded-[2rem] border border-white/15 bg-white shadow-2xl">
              <Image
                src="/images/hero-student.jpg"
                alt="A smiling Muslim student in school uniform and kufi cap, holding an open Qur'an in a school courtyard"
                width={1408}
                height={768}
                priority
                sizes="(min-width: 1024px) 36rem, 100vw"
                className="h-auto w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 left-4 right-4 grid grid-cols-3 gap-3 rounded-2xl bg-white p-4 text-center shadow-xl sm:left-8 sm:right-8">
              <div><p className="font-display text-2xl font-semibold text-navy-deep">{studentCount}+</p><p className="text-xs text-slate-600">Active students</p></div>
              <div><p className="font-display text-2xl font-semibold text-navy-deep">{teacherCount}</p><p className="text-xs text-slate-600">Teachers</p></div>
              <div><p className="font-display text-2xl font-semibold text-navy-deep">{passRate !== null ? `${passRate}%` : "—"}</p><p className="text-xs text-slate-600">Pass rate</p></div>
            </div>
          </div>
        </div>
      </section>

      {/* Page cards */}
      <Section className="pt-28">
        <SectionTitle eyebrow="Explore" title="Find out more about the school" description="Each section has its own page with the details you need." />
        <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {PAGES.map((p) => (
            <li key={p.href}>
              <Link href={p.href} className="focus-ring group flex h-full flex-col rounded-2xl border border-navy/10 bg-white p-6 shadow-card transition hover:-translate-y-0.5 hover:border-sky">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-sky-soft text-navy"><p.icon className="h-5 w-5" aria-hidden /></span>
                <h3 className="mt-4 font-display text-lg font-semibold text-navy-deep">{p.title}</h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-600">{p.body}</p>
                <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-navy group-hover:underline">Open page <ArrowRight className="h-4 w-4" aria-hidden /></span>
              </Link>
            </li>
          ))}
        </ul>
      </Section>

      {/* Final CTA */}
      <Section className="text-center">
        <StarDivider />
        <h2 className="mt-6 font-display text-3xl font-semibold text-navy-deep sm:text-4xl">Give your child a bright start</h2>
        <p className="mx-auto mt-4 max-w-xl text-slate-600">Apply online in a few minutes. You will receive an application reference to track your status.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/admissions/apply" className={cn(buttonVariants({ size: "lg" }))}><GraduationCap className="h-5 w-5" aria-hidden /> Apply for Admission</Link>
          <Link href="/contact" className={cn(buttonVariants({ variant: "outline", size: "lg" }))}>Talk to us</Link>
        </div>
      </Section>
    </>
  );
}
