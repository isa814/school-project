import type { Metadata } from "next";
import { Section, SectionTitle } from "@/components/public/Section";

export const metadata: Metadata = { title: "Gallery", description: "Photos of school life at Ansar Ruhul Islam School." };

// TODO: replace these placeholder tiles with real school photos (next/image, lazy loaded).
const TILES = [
  { label: "Morning assembly", from: "#0235A4", to: "#7EACEB" },
  { label: "ICT laboratory", from: "#021E66", to: "#0235A4" },
  { label: "Quran recitation", from: "#7EACEB", to: "#EAF2FD" },
  { label: "Sports day", from: "#0235A4", to: "#D4A150" },
  { label: "Science practical", from: "#021E66", to: "#7EACEB" },
  { label: "Graduation", from: "#D4A150", to: "#FBF3E4" },
];

export default function GalleryPage() {
  return (
    <Section>
      <SectionTitle eyebrow="Gallery" title="Life at Ansar Ruhul Islam" description="Placeholder images until official school photographs are added." />
      <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {TILES.map((t) => (
          <li key={t.label} className="group relative aspect-[4/3] overflow-hidden rounded-2xl shadow-card">
            <div className="absolute inset-0 transition-transform duration-500 group-hover:scale-105" style={{ background: `linear-gradient(135deg, ${t.from}, ${t.to})` }} aria-hidden />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-navy-deep/80 to-transparent p-4">
              <p className="text-sm font-semibold text-white">{t.label}</p>
            </div>
          </li>
        ))}
      </ul>
    </Section>
  );
}
