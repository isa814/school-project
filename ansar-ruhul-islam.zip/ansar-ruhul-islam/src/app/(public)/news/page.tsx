import Link from "next/link";
import type { Metadata } from "next";
import { db } from "@/lib/db";
import { Section, SectionTitle } from "@/components/public/Section";
import { formatDate } from "@/lib/utils";

export const metadata: Metadata = { title: "News & events", description: "Latest news and upcoming events from Ansar Ruhul Islam School." };

export default async function NewsPage() {
  const [news, events] = await Promise.all([
    db.newsPost.findMany({ where: { publishedAt: { not: null } }, orderBy: { publishedAt: "desc" } }),
    db.event.findMany({ orderBy: { date: "asc" } }),
  ]);
  return (
    <>
      <div className="lattice-navy text-white">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-sky">News & events</p>
          <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight sm:text-5xl">What is happening at school</h1>
        </div>
      </div>
      <Section>
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <SectionTitle eyebrow="News" title="Stories and updates" />
            <div className="grid gap-6 sm:grid-cols-2">
              {news.map((n) => (
                <Link key={n.id} href={`/news/${n.slug}`} className="focus-ring group rounded-2xl border border-navy/10 bg-white p-6 shadow-card hover:border-sky">
                  <p className="text-xs text-slate-500">{formatDate(n.publishedAt)}</p>
                  <h2 className="mt-2 font-display text-xl font-semibold text-navy-deep group-hover:text-navy">{n.title}</h2>
                  <p className="mt-2 text-sm text-slate-600">{n.excerpt}</p>
                  <span className="mt-4 inline-block text-sm font-semibold text-navy">Read more →</span>
                </Link>
              ))}
            </div>
          </div>
          <div>
            <SectionTitle eyebrow="Calendar" title="Events" />
            <ul className="space-y-4">
              {events.map((e) => (
                <li key={e.id} className="rounded-2xl border border-navy/10 bg-white p-5 shadow-card">
                  <p className="text-xs font-semibold uppercase tracking-wide text-navy/70">{formatDate(e.date)} · {e.type.toLowerCase()}</p>
                  <h3 className="mt-1 font-semibold text-navy-deep">{e.title}</h3>
                  <p className="mt-1 text-sm text-slate-600">{e.description}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>
    </>
  );
}
