import type { Metadata } from "next";
import { GraduationCap, BookOpenCheck, ShieldCheck } from "lucide-react";
import { LoginForm } from "./LoginForm";
import { Logo } from "@/components/shared/Logo";

export const metadata: Metadata = { title: "Portal login" };

export default function LoginPage({ searchParams }: { searchParams: { callbackUrl?: string } }) {
  return (
    <main className="grid min-h-screen lg:grid-cols-2">
      <section className="lattice-navy flex flex-col justify-between p-8 text-white sm:p-12">
        <Logo tone="light" />
        <div className="my-12 max-w-md">
          <h1 className="font-display text-4xl font-semibold leading-tight">Welcome to the school portal</h1>
          <p className="mt-4 text-sky/90">
            Staff, teachers and students sign in here. Parents view a child&apos;s results and fees through the student&apos;s Guardian View.
          </p>
          <ul className="mt-8 space-y-4 text-sm">
            <li className="flex items-center gap-3"><ShieldCheck className="h-5 w-5 text-sky" aria-hidden /> Role-based access for admin, teachers and students</li>
            <li className="flex items-center gap-3"><BookOpenCheck className="h-5 w-5 text-sky" aria-hidden /> Results, attendance, timetables and report cards</li>
            <li className="flex items-center gap-3"><GraduationCap className="h-5 w-5 text-sky" aria-hidden /> Secure online school fee payments</li>
          </ul>
        </div>
        <p className="text-xs text-sky/70">Knowledge is light · Ansar Ruhul Islam School</p>
      </section>
      <section className="flex items-center justify-center bg-white p-6 sm:p-12">
        <div className="w-full max-w-md">
          <LoginForm callbackUrl={searchParams.callbackUrl} />
        </div>
      </section>
    </main>
  );
}
