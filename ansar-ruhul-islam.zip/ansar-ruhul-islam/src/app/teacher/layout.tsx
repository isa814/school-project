import { requireRole } from "@/lib/session";
import { DashboardShell, type NavItem } from "@/components/shared/DashboardShell";

const NAV: NavItem[] = [
  { href: "/teacher", label: "Dashboard", icon: "LayoutDashboard" },
  { href: "/teacher/attendance", label: "Attendance", icon: "ClipboardList" },
  { href: "/teacher/scores", label: "Scores", icon: "Table2" },
  { href: "/teacher/materials", label: "Assignments & materials", icon: "FolderOpen" },
  { href: "/teacher/students", label: "My students", icon: "Users" },
  { href: "/teacher/timetable", label: "Timetable", icon: "CalendarDays" },
];

export default async function TeacherLayout({ children }: { children: React.ReactNode }) {
  const user = await requireRole("TEACHER");
  return <DashboardShell area="Teacher" userName={user.name} roleLabel="Teacher" nav={NAV}>{children}</DashboardShell>;
}
