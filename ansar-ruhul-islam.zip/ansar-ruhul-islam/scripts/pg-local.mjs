// Local-only helper: runs a PostgreSQL server for development when no DATABASE_URL is available.
// Usage: node scripts/pg-local.mjs   (keeps running; listens on localhost:5432)
import EmbeddedPostgres from "embedded-postgres";
import fs from "node:fs";
import path from "node:path";

const dataDir = path.resolve(process.cwd(), ".pgdata");
const pg = new EmbeddedPostgres({
  databaseDir: dataDir,
  user: "postgres",
  password: "postgres",
  port: 5432,
  persistent: true,
});

if (!fs.existsSync(dataDir)) {
  await pg.initialise();
}
await pg.start();
try {
  await pg.createDatabase("ansar_ruhul");
} catch {
  /* already exists */
}
console.log("PostgreSQL ready: postgresql://postgres:postgres@localhost:5432/ansar_ruhul");
process.on("SIGTERM", async () => { await pg.stop(); process.exit(0); });
process.on("SIGINT", async () => { await pg.stop(); process.exit(0); });
setInterval(() => {}, 1 << 30);
